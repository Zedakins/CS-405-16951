// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <string>

/// <summary>
/// Encrypts or decrypts a source string using the provided key via XOR.
/// </summary>
/// <param name="source">The input string to process.</param>
/// <param name="key">The key used for encryption / decryption.</param>
/// <returns>The transformed string.</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get lengths now for performance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Ensure valid input data.
    assert(key_length > 0);
    assert(source_length > 0);

    // Prepare an output string of the same length as source.
    std::string output;
    output.resize(source_length);

    // XOR each character of 'source' with a character of 'key'.
    // If 'key' is shorter than 'source', wrap around using the modulo operator.
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
    }

    // Output length should match source length.
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Reads the entire contents of a file into a single string.
/// </summary>
/// <param name="filename">Name of the file to read.</param>
/// <returns>A string containing the file's contents, or an empty string on error.</returns>
std::string read_file(const std::string& filename)
{
    // Open the file in read mode.
    std::ifstream infile(filename);
    if (!infile)
    {
        // If the file cannot be opened, return an empty string or handle error.
        std::cerr << "Error: Could not open file " << filename << std::endl;
        return "";
    }

    // Use an ostringstream to read the entire file content into a single string.
    std::ostringstream buffer;
    buffer << infile.rdbuf();

    // Return the collected string.
    return buffer.str();
}

/// <summary>
/// Extracts the student name from the data. The student name is expected to be on the first line.
/// </summary>
/// <param name="string_data">String containing file data.</param>
/// <returns>The student name (first line) or an empty string if not found.</returns>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the position of the first newline character.
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        // The student name is the substring before the newline.
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

/// <summary>
/// Saves data to a file in the specified format.
/// File format:
///  Line 1: Student name
///  Line 2: Current date (yyyy-mm-dd)
///  Line 3: Key used for encryption/decryption
///  Line 4+: The encrypted or decrypted data
/// </summary>
/// <param name="filename">Name of the file to write to.</param>
/// <param name="student_name">Name of the student.</param>
/// <param name="key">Key used for encryption/decryption.</param>
/// <param name="data">Data to be written to the file.</param>
void save_data_file(const std::string& filename,
                    const std::string& student_name,
                    const std::string& key,
                    const std::string& data)
{
    // Open the file in write mode.
    std::ofstream outfile(filename);
    if (!outfile)
    {
        std::cerr << "Error: Could not open file " << filename << " for writing." << std::endl;
        return;
    }

    // Write the student name (Line 1).
    outfile << student_name << "\n";

    // Generate the current date in yyyy-mm-dd format (Line 2).
    std::time_t t = std::time(nullptr);
    std::tm tm = *std::localtime(&t);
    char date_buffer[11];
    // Format: YYYY-MM-DD
    std::strftime(date_buffer, sizeof(date_buffer), "%Y-%m-%d", &tm);
    outfile << date_buffer << "\n";

    // Write the key (Line 3).
    outfile << key << "\n";

    // Write the data (Line 4+).
    outfile << data << "\n";
}

int main()
{
    std::cout << "Encryption / Decryption Test!" << std::endl;

    // Input file format (as specified):
    //  Line 1: <Student's Name>
    //  Line 2: <Website or source of lorem ipsum text>
    //  Lines 3+: <Lorem ipsum or other content>

    // Define the file names used for I/O.
    const std::string file_name           = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    // Read the input file into a string.
    const std::string source_string = read_file(file_name);

    // Define the key for XOR encryption/decryption.
    const std::string key = "password";

    // Extract the student name from the first line of the input data.
    const std::string student_name = get_student_name(source_string);

    // 1. Encrypt the source string using the key.
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // 2. Save the encrypted string to a file.
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // 3. Decrypt the previously encrypted string using the same key.
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // 4. Save the decrypted string to a file.
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    // Informational output.
    std::cout << "Read File: " << file_name
              << " - Encrypted To: " << encrypted_file_name
              << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}
