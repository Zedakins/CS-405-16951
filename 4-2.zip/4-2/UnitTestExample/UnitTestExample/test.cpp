// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <vector>
#include <memory>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <stdexcept>

//------------------------------------------------------------------------------
// Global Test Environment Setup and Tear Down
// You should not need to change anything here
//------------------------------------------------------------------------------
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // Initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

//------------------------------------------------------------------------------
// CollectionTest Test Fixture
// This class houses shared data between tests.
//------------------------------------------------------------------------------
class CollectionTest : public ::testing::Test
{
protected:
    // Smart pointer to hold our collection (vector of ints)
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // Erase all elements in the collection, if any remain, then free the pointer
        collection->clear();
        collection.reset(nullptr);
    }

    // Helper function to add random values (0 to 99) to the collection 'count' times
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

//------------------------------------------------------------------------------
// Predefined Tests
//------------------------------------------------------------------------------

// Test that the collection smart pointer is not null.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // Verify that the smart pointer has been initialized.
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that the collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent it from running.
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

//------------------------------------------------------------------------------
// TODO: Implemented Unit Tests
//------------------------------------------------------------------------------

// 1. Verify adding a single value to an empty collection.
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Ensure the collection is initially empty.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // Add a single random entry.
    add_entries(1);

    // Verify that the collection now has exactly one entry.
    ASSERT_EQ(collection->size(), 1);
}

// 2. Verify adding five values to the collection.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());

    // Add five random entries.
    add_entries(5);

    // Verify that the collection now contains exactly five entries.
    ASSERT_EQ(collection->size(), 5);
}

// 3. Verify that max_size is greater than or equal to size for 0, 1, 5, and 10 entries.
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    // Check for 0 entries.
    collection->clear();
    ASSERT_LE(collection->size(), collection->max_size());

    // Check for 1 entry.
    add_entries(1);
    ASSERT_LE(collection->size(), collection->max_size());
    collection->clear();

    // Check for 5 entries.
    add_entries(5);
    ASSERT_LE(collection->size(), collection->max_size());
    collection->clear();

    // Check for 10 entries.
    add_entries(10);
    ASSERT_LE(collection->size(), collection->max_size());
}

// 4. Verify that capacity is greater than or equal to size for 0, 1, 5, and 10 entries.
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    // For an empty vector, capacity should be >= size.
    ASSERT_LE(collection->size(), collection->capacity());

    // Check for 1 entry.
    add_entries(1);
    ASSERT_LE(collection->size(), collection->capacity());
    collection->clear();

    // Check for 5 entries.
    add_entries(5);
    ASSERT_LE(collection->size(), collection->capacity());
    collection->clear();

    // Check for 10 entries.
    add_entries(10);
    ASSERT_LE(collection->size(), collection->capacity());
}

// 5. Verify that resizing increases the collection.
TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    // Ensure the collection is empty.
    ASSERT_TRUE(collection->empty());

    // Resize the vector to 5 elements.
    collection->resize(5);

    // Verify that the size is now 5.
    ASSERT_EQ(collection->size(), 5);

    // Verify that new elements are default-initialized (0 for int).
    for (const auto& val : *collection)
    {
        EXPECT_EQ(val, 0);
    }
}

// 6. Verify that resizing decreases the collection.
TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    // Fill the collection with 10 entries.
    add_entries(10);
    size_t originalSize = collection->size();
    ASSERT_EQ(originalSize, 10);

    // Resize to 5, which should reduce the collection size.
    collection->resize(5);

    // Verify that the size has decreased to 5.
    ASSERT_EQ(collection->size(), 5);
}

// 7. Verify that resizing decreases the collection to zero.
TEST_F(CollectionTest, ResizingDecreasesToZero)
{
    // Add some entries to the collection.
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    // Resize to zero.
    collection->resize(0);

    // Verify that the collection is empty.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// 8. Verify that clear() erases the collection.
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add several entries.
    add_entries(5);
    ASSERT_FALSE(collection->empty());
    ASSERT_GT(collection->size(), 0);

    // Clear the collection.
    collection->clear();

    // Verify that the collection is empty.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// 9. Verify that erase(begin, end) erases the specified range from the collection.
TEST_F(CollectionTest, EraseRangeErasesCollection)
{
    // Add 10 entries.
    add_entries(10);
    size_t originalSize = collection->size();
    ASSERT_EQ(originalSize, 10);

    // Erase the first 3 elements.
    auto it = collection->begin();
    collection->erase(it, it + 3);

    // Verify that the collection size has decreased by 3.
    ASSERT_EQ(collection->size(), originalSize - 3);
}

// 10. Verify that reserve() increases the capacity but does not change the size.
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // Add 5 entries.
    add_entries(5);
    size_t currentSize = collection->size();
    size_t oldCapacity = collection->capacity();

    // Reserve a larger capacity.
    collection->reserve(100);

    // Verify that the capacity has increased to at least 100.
    ASSERT_GE(collection->capacity(), 100);

    // Verify that the size remains unchanged.
    ASSERT_EQ(collection->size(), currentSize);
}

// 11. Verify that std::out_of_range is thrown when calling at() with an out-of-bounds index.
TEST_F(CollectionTest, OutOfRangeAtThrowsException)
{
    // For an empty collection, accessing at(0) should throw an exception.
    ASSERT_THROW(collection->at(0), std::out_of_range);

    // Alternatively, add some entries and access an index that is out of range.
    add_entries(5);
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

//------------------------------------------------------------------------------
// Custom Tests
//------------------------------------------------------------------------------

// 12. Positive test: Verify that after adding a known value, the collection contains that value.
TEST_F(CollectionTest, ContainsAddedValue)
{
    int knownValue = 42;
    collection->push_back(knownValue);

    // Check that the known value is present in the collection.
    bool found = false;
    for (const auto& value : *collection)
    {
        if (value == knownValue)
        {
            found = true;
            break;
        }
    }
    ASSERT_TRUE(found);
}

// 13. Negative test: Verify that a value not added to the collection is not present.
TEST_F(CollectionTest, DoesNotContainNonAddedValue)
{
    int addedValue = 42;
    int notAddedValue = 99;
    collection->push_back(addedValue);

    // Check that notAddedValue is not present in the collection.
    bool found = false;
    for (const auto& value : *collection)
    {
        if (value == notAddedValue)
        {
            found = true;
            break;
        }
    }
    ASSERT_FALSE(found);
}
