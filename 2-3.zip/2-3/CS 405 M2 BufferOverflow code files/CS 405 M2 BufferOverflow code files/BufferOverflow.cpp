// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <string>   // for strlen, needed only if we want to do further checks

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced.
    //  We need to prevent this without changing the account_number variable or its position.
    //  We must also notify the user if they entered too much data.

    // 'account_number' must remain directly before 'user_input' in the code
    const std::string account_number = "CharlieBrown42";
    char user_input[20];  

    std::cout << "Enter a value: ";

    // ------------------------- CHANGES START -------------------------
    // Use getline to safely read up to 19 characters + null terminator.
    // If the user types more than 19 chars, 'std::cin.fail()' is set.
    std::cin.getline(user_input, 20);

    // Check if we exceeded 19 characters (leading to a truncated input)
    if (std::cin.fail())
    {
        // Clear the error flag
        std::cin.clear();

        // Read and discard leftover characters from the input buffer
        // so they don't interfere with further input
        std::string flush;
        std::getline(std::cin, flush);

        std::cout << "You entered too many characters. "
                  << "Input has been truncated to 19 characters.\n";
    }
    // -------------------------- CHANGES END --------------------------

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}
